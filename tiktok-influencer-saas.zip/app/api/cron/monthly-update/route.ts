import { createClient } from "@supabase/supabase-js"
import { fetchTikTokMetrics } from "@/lib/tiktok/api"
import { NextResponse } from "next/server"

const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: Request) {
  try {
    // Verify authorization (you can add a secret token here)
    const authHeader = request.headers.get("authorization")
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const currentMonth = new Date().toISOString().slice(0, 7) // YYYY-MM

    // Get all users with active subscriptions
    const { data: users } = await supabaseAdmin
      .from("users")
      .select("id, plan_status, plan_max_influencers")
      .eq("plan_status", "active")

    if (!users || users.length === 0) {
      return NextResponse.json({ message: "No active users to update" })
    }

    let totalUpdated = 0
    const results: any[] = []

    for (const user of users) {
      try {
        // Check if already updated this month
        const { data: existingLog } = await supabaseAdmin
          .from("monthly_update_log")
          .select("id")
          .eq("user_id", user.id)
          .eq("month", currentMonth)
          .single()

        if (existingLog) {
          results.push({ userId: user.id, status: "already_updated" })
          continue
        }

        // Get user's active influencers
        const { data: influencers } = await supabaseAdmin
          .from("influencers")
          .select("id, url_tiktok")
          .eq("user_id", user.id)
          .eq("estado", "activo")
          .limit(user.plan_max_influencers)

        if (!influencers || influencers.length === 0) {
          results.push({ userId: user.id, status: "no_influencers" })
          continue
        }

        let userUpdatedCount = 0

        // Update each influencer (with rate limiting)
        for (const influencer of influencers) {
          try {
            const metrics = await fetchTikTokMetrics(influencer.url_tiktok)

            await supabaseAdmin
              .from("influencers")
              .update({
                seguidores: metrics.seguidores,
                likes_promedio: metrics.likesPromedio,
                engagement_rate: metrics.engagementRate,
                ultima_actualizacion: new Date().toISOString(),
              })
              .eq("id", influencer.id)

            userUpdatedCount++
            totalUpdated++

            // Rate limiting: wait 1 second between requests
            await new Promise((resolve) => setTimeout(resolve, 1000))
          } catch (error) {
            console.error(`[v0] Error updating influencer ${influencer.id}:`, error)
          }
        }

        // Log the update
        await supabaseAdmin.from("monthly_update_log").insert({
          user_id: user.id,
          month: currentMonth,
          total_influencers_updated: userUpdatedCount,
          status: "completed",
        })

        results.push({ userId: user.id, status: "success", updated: userUpdatedCount })
      } catch (error) {
        console.error(`[v0] Error updating user ${user.id}:`, error)
        results.push({ userId: user.id, status: "error" })
      }
    }

    return NextResponse.json({
      message: "Monthly update completed",
      totalUpdated,
      results,
    })
  } catch (error) {
    console.error("[v0] Monthly update error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
