import { createClient } from "@/lib/supabase/server"
import { fetchTikTokMetrics } from "@/lib/tiktok/api"
import { NextResponse } from "next/server"

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { error } = await supabase.from("influencers").delete().eq("id", id).eq("user_id", user.id)

    if (error) {
      throw error
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error deleting influencer:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get current influencer data
    const { data: influencer } = await supabase
      .from("influencers")
      .select("url_tiktok")
      .eq("id", id)
      .eq("user_id", user.id)
      .single()

    if (!influencer) {
      return NextResponse.json({ error: "Influencer not found" }, { status: 404 })
    }

    // Fetch updated metrics
    const metrics = await fetchTikTokMetrics(influencer.url_tiktok)

    // Update influencer
    const { data: updated, error } = await supabase
      .from("influencers")
      .update({
        seguidores: metrics.seguidores,
        likes_promedio: metrics.likesPromedio,
        engagement_rate: metrics.engagementRate,
        ultima_actualizacion: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("user_id", user.id)
      .select()
      .single()

    if (error) {
      throw error
    }

    return NextResponse.json({ influencer: updated })
  } catch (error) {
    console.error("[v0] Error updating influencer:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
