import { createClient } from "@/lib/supabase/server"
import { fetchTikTokMetrics } from "@/lib/tiktok/api"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: influencers, error } = await supabase
      .from("influencers")
      .select("*")
      .eq("user_id", user.id)
      .order("creado_en", { ascending: false })

    if (error) {
      throw error
    }

    return NextResponse.json({ influencers })
  } catch (error) {
    console.error("[v0] Error fetching influencers:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { nombreCompleto, telefono, fechaNacimiento, urlTikTok } = body

    if (!nombreCompleto || !urlTikTok) {
      return NextResponse.json({ error: "Nombre completo y URL de TikTok son requeridos" }, { status: 400 })
    }

    // Check user's plan limit
    const { data: userData } = await supabase.from("users").select("plan_max_influencers").eq("id", user.id).single()

    const { count } = await supabase
      .from("influencers")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("estado", "activo")

    if (count !== null && userData && count >= userData.plan_max_influencers) {
      return NextResponse.json(
        { error: "Has alcanzado el límite de tu plan. Elimina un influencer o mejora de plan." },
        { status: 403 },
      )
    }

    // Fetch TikTok metrics
    const metrics = await fetchTikTokMetrics(urlTikTok)

    // Create influencer
    const { data: influencer, error } = await supabase
      .from("influencers")
      .insert({
        user_id: user.id,
        nombre_completo: nombreCompleto,
        telefono: telefono || null,
        fecha_nacimiento: fechaNacimiento || null,
        url_tiktok: urlTikTok,
        username: metrics.username,
        seguidores: metrics.seguidores,
        likes_promedio: metrics.likesPromedio,
        engagement_rate: metrics.engagementRate,
        ultima_actualizacion: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    return NextResponse.json({ influencer })
  } catch (error) {
    console.error("[v0] Error creating influencer:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
