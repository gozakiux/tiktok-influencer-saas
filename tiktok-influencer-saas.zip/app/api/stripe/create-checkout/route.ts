import { createClient } from "@/lib/supabase/server"
import { createCheckoutSession } from "@/lib/stripe/server"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { priceId } = await request.json()

    if (!priceId) {
      return NextResponse.json({ error: "Price ID is required" }, { status: 400 })
    }

    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user data
    const { data: userData } = await supabase.from("users").select("stripe_customer_id").eq("id", user.id).single()

    const session = await createCheckoutSession({
      priceId,
      userId: user.id,
      userEmail: user.email!,
      customerId: userData?.stripe_customer_id,
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("[v0] Error creating checkout session:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
