import { fetchTikTokMetrics } from "@/lib/tiktok/api"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { urlTikTok } = await request.json()

    if (!urlTikTok) {
      return NextResponse.json({ error: "TikTok URL is required" }, { status: 400 })
    }

    const metrics = await fetchTikTokMetrics(urlTikTok)

    return NextResponse.json(metrics)
  } catch (error) {
    console.error("[v0] Error in metrics API:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
