import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { CreditCard, Calendar, DollarSign, Package } from "lucide-react"
import Link from "next/link"
import { ManageSubscriptionButton } from "@/components/billing/manage-subscription-button"

export default async function BillingPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: userData } = await supabase.from("users").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      <DashboardHeader user={userData} />

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Facturación</h1>
          <p className="text-slate-400">Gestiona tu suscripción y métodos de pago</p>
        </div>

        <div className="grid gap-6">
          {/* Plan Actual */}
          <Card className="bg-slate-900/50 border-slate-800 p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">Plan {userData?.current_plan}</h2>
                <p className="text-slate-400">Tu plan actual y detalles de facturación</p>
              </div>
              <div className="px-4 py-2 bg-purple-500/20 text-purple-300 rounded-lg font-medium">
                {userData?.plan_status === "active" ? "Activo" : userData?.plan_status}
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-purple-500/20 rounded-lg">
                  <DollarSign className="h-5 w-5 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-400">Precio</p>
                  <p className="text-xl font-bold text-white">${userData?.plan_price}/mes</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-3 bg-pink-500/20 rounded-lg">
                  <Package className="h-5 w-5 text-pink-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-400">Límite</p>
                  <p className="text-xl font-bold text-white">{userData?.plan_max_influencers} influencers</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-3 bg-cyan-500/20 rounded-lg">
                  <Calendar className="h-5 w-5 text-cyan-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-400">Próximo Cobro</p>
                  <p className="text-lg font-bold text-white">
                    {userData?.plan_period_end
                      ? format(new Date(userData.plan_period_end), "dd MMM yyyy", { locale: es })
                      : "-"}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <ManageSubscriptionButton hasCustomerId={!!userData?.stripe_customer_id} />
              <Button
                variant="outline"
                asChild
                className="border-purple-500 text-purple-400 hover:bg-purple-500/10 bg-transparent"
              >
                <Link href="/pricing">Cambiar de Plan</Link>
              </Button>
            </div>
          </Card>

          {/* Método de Pago */}
          <Card className="bg-slate-900/50 border-slate-800 p-6">
            <div className="flex items-center gap-3 mb-4">
              <CreditCard className="h-6 w-6 text-purple-400" />
              <h2 className="text-xl font-bold text-white">Método de Pago</h2>
            </div>
            <p className="text-slate-400 mb-4">
              {userData?.stripe_customer_id
                ? "Gestiona tus métodos de pago en el portal de Stripe."
                : "Aún no has configurado un método de pago. Suscríbete a un plan para empezar."}
            </p>
            {userData?.stripe_customer_id && (
              <p className="text-sm text-slate-500">Stripe Customer ID: {userData.stripe_customer_id}</p>
            )}
          </Card>

          {/* Información de Actualización Mensual */}
          <Card className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-500/50 p-6">
            <h2 className="text-xl font-bold text-white mb-2">Actualización Automática Mensual</h2>
            <p className="text-slate-300 mb-4">
              Todos tus influencers activos se actualizan automáticamente el primer día de cada mes. No necesitas hacer
              nada.
            </p>
            <p className="text-sm text-slate-400">
              Próxima actualización automática:{" "}
              <span className="text-purple-400 font-medium">1 de {format(new Date(), "MMMM", { locale: es })}</span>
            </p>
          </Card>
        </div>
      </main>
    </div>
  )
}
