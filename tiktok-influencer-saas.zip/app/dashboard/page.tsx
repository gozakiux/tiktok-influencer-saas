import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { InfluencersTable } from "@/components/dashboard/influencers-table"
import { ImportExcelButton } from "@/components/dashboard/import-excel-button"
import { AddInfluencerDialog } from "@/components/dashboard/add-influencer-dialog"

export default async function DashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: userData } = await supabase.from("users").select("*").eq("id", user.id).single()

  const { data: influencers, count } = await supabase
    .from("influencers")
    .select("*", { count: "exact" })
    .eq("user_id", user.id)
    .eq("estado", "activo")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      <DashboardHeader user={userData} />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
          <p className="text-slate-400">Gestiona y monitorea tus influencers de TikTok</p>
        </div>

        <StatsCards
          totalInfluencers={count || 0}
          maxInfluencers={userData?.plan_max_influencers || 20}
          currentPlan={userData?.current_plan || "BASIC"}
          nextUpdate={userData?.plan_period_end}
        />

        <div className="flex gap-4 mb-6">
          <ImportExcelButton />
          <AddInfluencerDialog />
        </div>

        <InfluencersTable initialInfluencers={influencers || []} />
      </main>
    </div>
  )
}
