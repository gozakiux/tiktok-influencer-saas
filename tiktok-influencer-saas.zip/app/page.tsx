import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { TrendingUp, Users, BarChart3, Zap, Shield, Clock } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
            TikTok Influencer Tracker
          </h1>
          <div className="flex gap-3">
            <Button variant="ghost" asChild className="text-slate-300">
              <Link href="/auth/login">Iniciar Sesión</Link>
            </Button>
            <Button
              asChild
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Link href="/auth/register">Empezar Gratis</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Rastrea y Gestiona Microinfluencers de{" "}
            <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
              TikTok
            </span>
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto leading-relaxed">
            Monitorea métricas, engagement y rendimiento de tus influencers favoritos. Actualización automática mensual
            y análisis en tiempo real.
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              size="lg"
              asChild
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-lg px-8"
            >
              <Link href="/auth/register">Empieza Ahora</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-purple-500 text-purple-400 hover:bg-purple-500/10 text-lg px-8 bg-transparent"
            >
              <Link href="/pricing">Ver Planes</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-purple-500/50 transition-colors">
            <TrendingUp className="h-12 w-12 text-purple-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Métricas en Tiempo Real</h3>
            <p className="text-slate-400">
              Obtén seguidores, likes promedio y engagement rate actualizados automáticamente cada mes.
            </p>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-pink-500/50 transition-colors">
            <Users className="h-12 w-12 text-pink-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Gestión Masiva</h3>
            <p className="text-slate-400">
              Importa hasta 10,000 influencers desde Excel y gestiónalos desde un solo dashboard.
            </p>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-cyan-500/50 transition-colors">
            <BarChart3 className="h-12 w-12 text-cyan-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Análisis Detallado</h3>
            <p className="text-slate-400">
              Visualiza engagement, compara influencers y toma decisiones basadas en datos.
            </p>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-purple-500/50 transition-colors">
            <Clock className="h-12 w-12 text-purple-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Actualización Automática</h3>
            <p className="text-slate-400">
              Todas las métricas se actualizan automáticamente el primer día de cada mes.
            </p>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-pink-500/50 transition-colors">
            <Shield className="h-12 w-12 text-pink-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Seguro y Privado</h3>
            <p className="text-slate-400">
              Tus datos están completamente aislados. Solo tú puedes ver tus influencers.
            </p>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 p-6 hover:border-cyan-500/50 transition-colors">
            <Zap className="h-12 w-12 text-cyan-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Rápido y Escalable</h3>
            <p className="text-slate-400">
              Infraestructura optimizada para manejar miles de influencers sin ralentizar.
            </p>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 border-purple-500/50 p-12 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">¿Listo para empezar?</h2>
          <p className="text-xl text-slate-300 mb-8">
            Únete a cientos de marcas que ya rastrean influencers con nosotros.
          </p>
          <Button size="lg" asChild className="bg-white text-purple-900 hover:bg-slate-100 text-lg px-8">
            <Link href="/auth/register">Crear Cuenta Gratis</Link>
          </Button>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-8 text-center text-slate-400">
          <p>&copy; 2025 TikTok Influencer Tracker. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
