import { Button } from "@/components/ui/button"
import Link from "next/link"
import { PricingCard } from "@/components/pricing/pricing-card"

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
              TikTok Influencer Tracker
            </h1>
          </Link>
          <div className="flex gap-3">
            <Button variant="ghost" asChild className="text-slate-300">
              <Link href="/auth/login">Iniciar Sesión</Link>
            </Button>
            <Button
              asChild
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Link href="/auth/register">Empezar Gratis</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Pricing Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-4">Planes para cada necesidad</h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Elige el plan perfecto para tu estrategia de influencer marketing. Actualización automática mensual incluida
            en todos los planes.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <PricingCard
            name="Básico"
            price={20}
            maxInfluencers={20}
            priceId={process.env.NEXT_PUBLIC_STRIPE_BASIC_PRICE_ID || ""}
            features={[
              "20 influencers activos",
              "Actualización automática mensual",
              "Métricas completas (seguidores, likes, engagement)",
              "Importar desde Excel",
              "Dashboard completo",
              "Soporte por email",
            ]}
          />

          <PricingCard
            name="Premium"
            price={30}
            maxInfluencers={1000}
            priceId={process.env.NEXT_PUBLIC_STRIPE_PREMIUM_PRICE_ID || ""}
            popular
            features={[
              "1,000 influencers activos",
              "Actualización automática mensual",
              "Métricas completas (seguidores, likes, engagement)",
              "Importar desde Excel",
              "Dashboard completo",
              "Exportar a Excel",
              "Soporte prioritario",
            ]}
          />

          <PricingCard
            name="Mega"
            price={100}
            maxInfluencers={10000}
            priceId={process.env.NEXT_PUBLIC_STRIPE_MEGA_PRICE_ID || ""}
            features={[
              "10,000 influencers activos",
              "Actualización automática mensual",
              "Métricas completas (seguidores, likes, engagement)",
              "Importar desde Excel",
              "Dashboard completo",
              "Exportar a Excel",
              "API access",
              "Soporte VIP 24/7",
            ]}
          />
        </div>

        <div className="mt-16 text-center">
          <p className="text-slate-400 mb-4">
            Todos los planes incluyen actualización automática el primer día de cada mes
          </p>
          <p className="text-slate-500 text-sm">
            Puedes cambiar o cancelar tu plan en cualquier momento desde tu dashboard
          </p>
        </div>
      </section>
    </div>
  )
}
