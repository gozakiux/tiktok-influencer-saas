"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Loader2 } from "lucide-react"
import { useState } from "react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

export function AddInfluencerDialog() {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    nombreCompleto: "",
    telefono: "",
    fechaNacimiento: "",
    urlTikTok: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/influencers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        toast.success("Influencer agregado correctamente")
        setOpen(false)
        setFormData({ nombreCompleto: "", telefono: "", fechaNacimiento: "", urlTikTok: "" })
        router.refresh()
      } else {
        toast.error(data.error || "Error al agregar influencer")
      }
    } catch (error) {
      toast.error("Error inesperado")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/10 bg-transparent">
          <Plus className="mr-2 h-4 w-4" />
          Añadir Influencer
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-slate-900 border-slate-800">
        <DialogHeader>
          <DialogTitle className="text-white">Añadir Nuevo Influencer</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nombreCompleto" className="text-slate-300">
              Nombre Completo *
            </Label>
            <Input
              id="nombreCompleto"
              value={formData.nombreCompleto}
              onChange={(e) => setFormData({ ...formData, nombreCompleto: e.target.value })}
              required
              className="bg-slate-800/50 border-slate-700"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="urlTikTok" className="text-slate-300">
              URL de TikTok *
            </Label>
            <Input
              id="urlTikTok"
              placeholder="https://tiktok.com/@username"
              value={formData.urlTikTok}
              onChange={(e) => setFormData({ ...formData, urlTikTok: e.target.value })}
              required
              className="bg-slate-800/50 border-slate-700"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="telefono" className="text-slate-300">
              Teléfono
            </Label>
            <Input
              id="telefono"
              type="tel"
              value={formData.telefono}
              onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
              className="bg-slate-800/50 border-slate-700"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="fechaNacimiento" className="text-slate-300">
              Fecha de Nacimiento
            </Label>
            <Input
              id="fechaNacimiento"
              type="date"
              value={formData.fechaNacimiento}
              onChange={(e) => setFormData({ ...formData, fechaNacimiento: e.target.value })}
              className="bg-slate-800/50 border-slate-700"
            />
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Añadir Influencer
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
