"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Upload, Loader2 } from "lucide-react"
import { useState, useRef } from "react"
import { toast } from "sonner"
import * as XLSX from "xlsx"
import { useRouter } from "next/navigation"

interface ExcelRow {
  nombre_completo: string
  telefono?: string
  fecha_nacimiento?: string
  url_tiktok: string
}

export function ImportExcelButton() {
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsLoading(true)

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data)
      const worksheet = workbook.Sheets[workbook.SheetNames[0]]
      const jsonData = XLSX.utils.sheet_to_json<ExcelRow>(worksheet)

      let successCount = 0
      let errorCount = 0

      for (const row of jsonData) {
        try {
          const response = await fetch("/api/influencers", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              nombreCompleto: row.nombre_completo,
              telefono: row.telefono,
              fechaNacimiento: row.fecha_nacimiento,
              urlTikTok: row.url_tiktok,
            }),
          })

          if (response.ok) {
            successCount++
          } else {
            errorCount++
            const error = await response.json()
            if (response.status === 403) {
              toast.error(error.error)
              break
            }
          }
        } catch (error) {
          errorCount++
        }
      }

      if (successCount > 0) {
        toast.success(`${successCount} influencers importados correctamente`)
        router.refresh()
      }

      if (errorCount > 0) {
        toast.error(`${errorCount} influencers no pudieron ser importados`)
      }
    } catch (error) {
      toast.error("Error al procesar el archivo Excel")
    } finally {
      setIsLoading(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  return (
    <>
      <input type="file" ref={fileInputRef} accept=".xlsx,.xls" onChange={handleFileUpload} className="hidden" />
      <Button
        onClick={() => fileInputRef.current?.click()}
        disabled={isLoading}
        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
      >
        {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
        Importar Excel
      </Button>
    </>
  )
}
