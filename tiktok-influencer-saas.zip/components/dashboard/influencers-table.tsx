"use client"

import { useState } from "react"
import type { Influencer } from "@/lib/types/database"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, RefreshCw, Search, ArrowUpDown } from "lucide-react"
import { toast } from "sonner"
import { format, differenceInYears } from "date-fns"
import { es } from "date-fns/locale"

export function InfluencersTable({ initialInfluencers }: { initialInfluencers: Influencer[] }) {
  const [influencers, setInfluencers] = useState(initialInfluencers)
  const [search, setSearch] = useState("")
  const [sortField, setSortField] = useState<keyof Influencer>("creado_en")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  const handleDelete = async (id: string) => {
    if (!confirm("¿Estás seguro de eliminar este influencer?")) return

    try {
      const response = await fetch(`/api/influencers/${id}`, { method: "DELETE" })

      if (response.ok) {
        setInfluencers((prev) => prev.filter((inf) => inf.id !== id))
        toast.success("Influencer eliminado")
      } else {
        toast.error("Error al eliminar")
      }
    } catch (error) {
      toast.error("Error inesperado")
    }
  }

  const handleRefresh = async (id: string) => {
    try {
      const response = await fetch(`/api/influencers/${id}`, { method: "PATCH" })

      if (response.ok) {
        const { influencer } = await response.json()
        setInfluencers((prev) => prev.map((inf) => (inf.id === id ? influencer : inf)))
        toast.success("Métricas actualizadas")
      } else {
        toast.error("Error al actualizar")
      }
    } catch (error) {
      toast.error("Error inesperado")
    }
  }

  const handleSort = (field: keyof Influencer) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("desc")
    }
  }

  const filteredInfluencers = influencers
    .filter(
      (inf) =>
        inf.nombre_completo.toLowerCase().includes(search.toLowerCase()) ||
        inf.username.toLowerCase().includes(search.toLowerCase()),
    )
    .sort((a, b) => {
      const aVal = a[sortField]
      const bVal = b[sortField]

      if (aVal === null || bVal === null) return 0

      if (sortDirection === "asc") {
        return aVal > bVal ? 1 : -1
      } else {
        return aVal < bVal ? 1 : -1
      }
    })

  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar por nombre o username..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-slate-800/50 border-slate-700"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-slate-800">
              <TableHead className="text-slate-300">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("nombre_completo")}
                  className="text-slate-300"
                >
                  Nombre <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="text-slate-300">Username</TableHead>
              <TableHead className="text-slate-300">
                <Button variant="ghost" size="sm" onClick={() => handleSort("seguidores")} className="text-slate-300">
                  Seguidores <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="text-slate-300">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("likes_promedio")}
                  className="text-slate-300"
                >
                  Likes Promedio <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="text-slate-300">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("engagement_rate")}
                  className="text-slate-300"
                >
                  Engagement <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead className="text-slate-300">Teléfono</TableHead>
              <TableHead className="text-slate-300">Edad</TableHead>
              <TableHead className="text-slate-300">Última Actualización</TableHead>
              <TableHead className="text-slate-300">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInfluencers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-slate-400 py-8">
                  No hay influencers. Importa desde Excel o añade uno manualmente.
                </TableCell>
              </TableRow>
            ) : (
              filteredInfluencers.map((influencer) => (
                <TableRow key={influencer.id} className="border-slate-800">
                  <TableCell className="font-medium text-white">{influencer.nombre_completo}</TableCell>
                  <TableCell className="text-purple-400">@{influencer.username}</TableCell>
                  <TableCell className="text-slate-300">{influencer.seguidores.toLocaleString()}</TableCell>
                  <TableCell className="text-slate-300">{influencer.likes_promedio.toLocaleString()}</TableCell>
                  <TableCell className="text-slate-300">{influencer.engagement_rate}%</TableCell>
                  <TableCell className="text-slate-300">{influencer.telefono || "-"}</TableCell>
                  <TableCell className="text-slate-300">
                    {influencer.fecha_nacimiento
                      ? `${differenceInYears(new Date(), new Date(influencer.fecha_nacimiento))} años`
                      : "-"}
                  </TableCell>
                  <TableCell className="text-slate-300">
                    {influencer.ultima_actualizacion
                      ? format(new Date(influencer.ultima_actualizacion), "dd MMM yyyy", { locale: es })
                      : "-"}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="ghost" onClick={() => handleRefresh(influencer.id)}>
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(influencer.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
