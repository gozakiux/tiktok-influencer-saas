import { Card } from "@/components/ui/card"
import { Users, TrendingUp, Calendar, Award } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"

interface StatsCardsProps {
  totalInfluencers: number
  maxInfluencers: number
  currentPlan: string
  nextUpdate: string | null
}

export function StatsCards({ totalInfluencers, maxInfluencers, currentPlan, nextUpdate }: StatsCardsProps) {
  const usagePercentage = (totalInfluencers / maxInfluencers) * 100

  return (
    <div className="grid md:grid-cols-4 gap-6 mb-8">
      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-purple-500/20 rounded-lg">
            <Users className="h-6 w-6 text-purple-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Influencers Activos</p>
            <p className="text-2xl font-bold text-white">
              {totalInfluencers} / {maxInfluencers}
            </p>
          </div>
        </div>
      </Card>

      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-pink-500/20 rounded-lg">
            <TrendingUp className="h-6 w-6 text-pink-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Uso del Plan</p>
            <p className="text-2xl font-bold text-white">{usagePercentage.toFixed(0)}%</p>
          </div>
        </div>
      </Card>

      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-cyan-500/20 rounded-lg">
            <Award className="h-6 w-6 text-cyan-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Plan Actual</p>
            <p className="text-2xl font-bold text-white">{currentPlan}</p>
          </div>
        </div>
      </Card>

      <Card className="bg-slate-900/50 border-slate-800 p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-green-500/20 rounded-lg">
            <Calendar className="h-6 w-6 text-green-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Próxima Actualización</p>
            <p className="text-lg font-bold text-white">
              {nextUpdate ? format(new Date(nextUpdate), "d MMM", { locale: es }) : "1 del mes"}
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
