"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Check } from "lucide-react"
import { useState } from "react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

interface PricingCardProps {
  name: string
  price: number
  maxInfluencers: number
  priceId: string
  features: string[]
  popular?: boolean
}

export function PricingCard({ name, price, maxInfluencers, priceId, features, popular }: PricingCardProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleSubscribe = async () => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/stripe/create-checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ priceId }),
      })

      const data = await response.json()

      if (response.ok && data.url) {
        window.location.href = data.url
      } else {
        if (response.status === 401) {
          toast.error("Debes iniciar sesión primero")
          router.push("/auth/login")
        } else {
          toast.error("Error al crear sesión de pago")
        }
      }
    } catch (error) {
      toast.error("Error inesperado")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card
      className={`p-8 ${
        popular
          ? "bg-gradient-to-b from-purple-900/50 to-pink-900/50 border-purple-500 relative"
          : "bg-slate-900/50 border-slate-800"
      }`}
    >
      {popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-bold px-4 py-1 rounded-full">
            MÁS POPULAR
          </span>
        </div>
      )}

      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-white mb-2">{name}</h3>
        <div className="flex items-baseline justify-center gap-1">
          <span className="text-5xl font-bold text-white">${price}</span>
          <span className="text-slate-400">/mes</span>
        </div>
        <p className="text-slate-400 mt-2">{maxInfluencers.toLocaleString()} influencers</p>
      </div>

      <Button
        onClick={handleSubscribe}
        disabled={isLoading}
        className={`w-full mb-6 ${
          popular
            ? "bg-white text-purple-900 hover:bg-slate-100"
            : "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        }`}
      >
        {isLoading ? "Cargando..." : "Elegir Plan"}
      </Button>

      <ul className="space-y-3">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-3">
            <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
            <span className="text-slate-300">{feature}</span>
          </li>
        ))}
      </ul>
    </Card>
  )
}
