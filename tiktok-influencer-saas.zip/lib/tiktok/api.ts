export interface TikTokMetrics {
  username: string
  seguidores: number
  likesPromedio: number
  engagementRate: number
}

export async function fetchTikTokMetrics(urlTikTok: string): Promise<TikTokMetrics> {
  // Extract username from URL
  const username = extractUsername(urlTikTok)

  if (!username) {
    throw new Error("Invalid TikTok URL")
  }

  try {
    const response = await fetch(`https://tiktok-scraper7.p.rapidapi.com/user/info?unique_id=${username}`, {
      headers: {
        "x-rapidapi-key": process.env.RAPIDAPI_KEY!,
        "x-rapidapi-host": "tiktok-scraper7.p.rapidapi.com",
      },
    })

    if (!response.ok) {
      throw new Error(`TikTok API error: ${response.statusText}`)
    }

    const data = await response.json()

    // Extract metrics from response
    const followers = data.data?.user?.stats?.followerCount || 0
    const totalLikes = data.data?.user?.stats?.heart || 0
    const videoCount = data.data?.user?.stats?.videoCount || 1

    const likesPromedio = videoCount > 0 ? totalLikes / videoCount : 0
    const engagementRate = followers > 0 ? (likesPromedio / followers) * 100 : 0

    return {
      username,
      seguidores: followers,
      likesPromedio: Math.round(likesPromedio),
      engagementRate: Number.parseFloat(engagementRate.toFixed(2)),
    }
  } catch (error) {
    console.error("[v0] Error fetching TikTok metrics:", error)
    throw new Error("Failed to fetch TikTok metrics")
  }
}

function extractUsername(url: string): string | null {
  // Handle direct username
  if (!url.includes("/") && !url.includes("http")) {
    return url.replace("@", "")
  }

  // Extract from URL
  const patterns = [/tiktok\.com\/@([^/?]+)/, /tiktok\.com\/([^/@?]+)/, /vm\.tiktok\.com\/([^/?]+)/]

  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match) {
      return match[1].replace("@", "")
    }
  }

  return null
}
