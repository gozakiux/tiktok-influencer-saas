export type PlanType = "BASIC" | "PREMIUM" | "MEGA"
export type PlanStatus = "trialing" | "active" | "past_due" | "canceled" | "incomplete"
export type InfluencerStatus = "activo" | "en_revision" | "pausado" | "inactivo"

export interface User {
  id: string
  email: string
  created_at: string
  updated_at: string
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  current_plan: PlanType
  plan_max_influencers: number
  plan_price: number
  plan_status: PlanStatus
  plan_renewal_date: string | null
  plan_period_start: string | null
  plan_period_end: string | null
}

export interface Influencer {
  id: string
  user_id: string
  nombre_completo: string
  telefono: string | null
  fecha_nacimiento: string | null
  url_tiktok: string
  username: string
  seguidores: number
  likes_promedio: number
  engagement_rate: number
  estado: InfluencerStatus
  ultima_actualizacion: string | null
  creado_en: string
}

export interface MonthlyUpdateLog {
  id: string
  user_id: string
  month: string
  executed_at: string
  total_influencers_updated: number
  status: "pending" | "in_progress" | "completed" | "failed"
}

export const PLANS = {
  BASIC: {
    name: "Básico",
    price: 20,
    maxInfluencers: 20,
    priceId: process.env.NEXT_PUBLIC_STRIPE_BASIC_PRICE_ID || "",
  },
  PREMIUM: {
    name: "Premium",
    price: 30,
    maxInfluencers: 1000,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PREMIUM_PRICE_ID || "",
  },
  MEGA: {
    name: "Mega",
    price: 100,
    maxInfluencers: 10000,
    priceId: process.env.NEXT_PUBLIC_STRIPE_MEGA_PRICE_ID || "",
  },
} as const
