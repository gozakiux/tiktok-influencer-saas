-- TikTok Influencer SaaS Database Schema
-- This script creates all necessary tables for the application

-- Users table (extends auth.users from Supabase)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Stripe data
  stripe_customer_id TEXT UNIQUE,
  stripe_subscription_id TEXT,
  
  -- Plan information
  current_plan TEXT DEFAULT 'BASIC' CHECK (current_plan IN ('BASIC', 'PREMIUM', 'MEGA')),
  plan_max_influencers INTEGER DEFAULT 20,
  plan_price INTEGER DEFAULT 20,
  plan_status TEXT DEFAULT 'active' CHECK (plan_status IN ('trialing', 'active', 'past_due', 'canceled', 'incomplete')),
  plan_renewal_date TIMESTAMP WITH TIME ZONE,
  plan_period_start TIMESTAMP WITH TIME ZONE,
  plan_period_end TIMESTAMP WITH TIME ZONE
);

-- Influencers table
CREATE TABLE IF NOT EXISTS public.influencers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  
  -- Personal data from Excel
  nombre_completo TEXT NOT NULL,
  telefono TEXT,
  fecha_nacimiento DATE,
  
  -- TikTok data
  url_tiktok TEXT NOT NULL,
  username TEXT NOT NULL,
  
  -- Metrics from TikTok API
  seguidores INTEGER DEFAULT 0,
  likes_promedio DECIMAL(10, 2) DEFAULT 0,
  engagement_rate DECIMAL(5, 2) DEFAULT 0,
  
  -- Status and tracking
  estado TEXT DEFAULT 'activo' CHECK (estado IN ('activo', 'en_revision', 'pausado', 'inactivo')),
  ultima_actualizacion TIMESTAMP WITH TIME ZONE,
  creado_en TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  CONSTRAINT unique_user_username UNIQUE(user_id, username)
);

-- Monthly update log table
CREATE TABLE IF NOT EXISTS public.monthly_update_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  month TEXT NOT NULL, -- Format: YYYY-MM
  executed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  total_influencers_updated INTEGER DEFAULT 0,
  status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'in_progress', 'completed', 'failed')),
  
  CONSTRAINT unique_user_month UNIQUE(user_id, month)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_influencers_user_id ON public.influencers(user_id);
CREATE INDEX IF NOT EXISTS idx_influencers_estado ON public.influencers(estado);
CREATE INDEX IF NOT EXISTS idx_influencers_username ON public.influencers(username);
CREATE INDEX IF NOT EXISTS idx_monthly_log_user_month ON public.monthly_update_log(user_id, month);
CREATE INDEX IF NOT EXISTS idx_users_stripe_customer ON public.users(stripe_customer_id);

-- Enable Row Level Security
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.influencers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_update_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can view own data" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- RLS Policies for influencers table
CREATE POLICY "Users can view own influencers" ON public.influencers
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own influencers" ON public.influencers
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own influencers" ON public.influencers
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own influencers" ON public.influencers
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for monthly_update_log table
CREATE POLICY "Users can view own update logs" ON public.monthly_update_log
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can insert logs" ON public.monthly_update_log
  FOR INSERT WITH CHECK (true);
