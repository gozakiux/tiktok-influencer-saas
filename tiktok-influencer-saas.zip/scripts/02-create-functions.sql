-- Helper functions for the application

-- Function to get user's current influencer count
CREATE OR REPLACE FUNCTION public.get_user_influencer_count(p_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO v_count
  FROM public.influencers
  WHERE user_id = p_user_id AND estado = 'activo';
  
  RETURN v_count;
END;
$$;

-- Function to check if user can add more influencers
CREATE OR REPLACE FUNCTION public.can_add_influencer(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_count INTEGER;
  v_max_count INTEGER;
BEGIN
  -- Get current active influencer count
  SELECT COUNT(*)
  INTO v_current_count
  FROM public.influencers
  WHERE user_id = p_user_id AND estado = 'activo';
  
  -- Get user's plan limit
  SELECT plan_max_influencers
  INTO v_max_count
  FROM public.users
  WHERE id = p_user_id;
  
  RETURN v_current_count < v_max_count;
END;
$$;

-- Function to update user after successful auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.users (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Trigger to create user record on auth.users insert
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
